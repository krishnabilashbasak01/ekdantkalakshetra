<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.

$routes->get('/', 'Home::index', ['as' => 'client.home']);
$routes->add('/sign-in', 'Home::signIn', ['as' => 'client.login']);
$routes->add('/contact-us', 'Home::contact', ['as' => 'client.contact']);
$routes->add('/blogs', 'Home::blogs', ['as' => 'client.blogs']);
$routes->add('/blog/(:any)', 'Home::blog/$1');
$routes->add('/gallery/', 'Home::gallery', ['as' => 'client.gallery']);
$routes->add('/gallery-details/(:any)', 'Home::galleryDetails/$1', ['as' => 'client.gallery-details']);
$routes->add('/store/', 'Home::store', ['as' => 'client.store']);
$routes->add('/store/(:any)', 'Home::store/$1');
$routes->add('/product/(:any)', 'Home::product/$1');
$routes->add('/add-to-cart/(:any)', 'Home::addToCart/$1', ['as' => 'client.addCart', 'filter' => 'userAuth']);
$routes->add('/decrease-cart-item/(:any)', 'Home::decreaseCartItem/$1', ['as' => 'client.decreasecartitem', 'filter' => 'userAuth']);
$routes->add('/delete-cart-item/(:any)', 'Home::deleteCartItem/$1', ['as' => 'client.deleteCartItem', 'filter' => 'userAuth']);
$routes->add('/create-address', 'Home::createAddress', ['as' => 'client.createAddress', 'filter' => 'userAuth']);
$routes->add('/edit-address/(:any)', 'Home::editAddress/$1', ['as' => 'client.editAddress', 'filter' => 'userAuth']);
$routes->add('/get-address/(:any)', 'Home::getAddress/$1', ['as' => 'client.getAddress', 'filter' => 'userAuth']);
$routes->add('/place-order', 'Home::placeOrder', ['as' => 'client.placeOrder', 'filter' => 'userAuth']);
$routes->add('/order-complete/(:any)', 'Home::orderComplete/$1', ['as' => 'client.orderComplete', 'filter' => 'userAuth']);
$routes->add('/orders-details/(:any)', 'Home::orderDetails/$1', ['as' => 'client.orderDetails', 'filter' => 'userAuth']);
$routes->add('/purchase-process', 'Home::purchaseProcess/$1', ['as' => 'client.purchase-process', 'filter' => 'userAuth']);


$routes->add('/cart', 'Home::cart', ['filter' => 'userAuth']);
$routes->add('/account', 'Home::account', ['as' => 'client.account', 'filter' => 'userAuth']);
$routes->add('/faq', 'Home::faq');
$routes->add('/privacy-policy', 'Home::privacyPolicy');
$routes->add('/terms-conditions', 'Home::termsConditions');
$routes->add('/about', 'Home::about');
$routes->add('/logout', 'Home::logout', ['as' => 'client.logout', 'filter' => 'userAuth']);

$routes->group("blog-api", function($routes){
    $routes->get('get-all-blogs', 'BlogApiController::index');
    $routes->add('create', 'BlogApiController::create');
    $routes->add('edit', 'BlogApiController::edit');
    $routes->add('delete', 'BlogApiController::delete');
    $routes->add('picture-upload', 'BlogApiController::PictureUpload');
    $routes->get('blog-categories', 'BlogApiController::Categories');
});

$routes->group("admin", function ($routes) {
    $routes->add('/', 'Admin::index', ['as' => 'admin.dashboard', 'filter' => 'auth']);
    $routes->add('/dashboard', 'Admin::index', ['as' => 'admin.dashboard', 'filter' => 'auth']);
    $routes->add('sign-in', 'Admin::signIn', ['as' => 'admin.sign-in']);
    $routes->add('sign-up', 'Admin::signUp', ['as' => 'admin.sign-up']);
    $routes->add('create-blog', 'Admin::createBlog', ['as' => 'admin.create-blog', 'filter' => 'auth']);
    $routes->add('blog-category', 'Admin::blogCategory', ['as' => 'admin.blog-category', 'filter' => 'auth']);
    $routes->add('blog-list', 'Admin::blogs', ['as' => 'admin.blog-list', 'filter' => 'auth']);
    $routes->add('edit-blog/(:any)', 'Admin::editBlog/$1', ['filter' => 'auth']);
    //    delete
    $routes->add('delete-blog-category/(:any)', 'Admin::deleteBlogCategory/$1', ['filter' => 'auth']);
    $routes->add('delete-blog/(:any)', 'Admin::deleteBlog/$1', ['filter' => 'auth']);

    $routes->add('products', 'Admin::products', ['as' => 'admin.products', 'filter' => 'auth']);
    $routes->add('create-product', 'Admin::createProducts', ['as' => 'admin.createProducts', 'filter' => 'auth']);
    $routes->add('edit-product/(:any)', 'Admin::editProduct/$1', ['as' => 'admin.edit-product', 'filter' => 'auth']);
    $routes->add('edit-book-details/(:any)', 'Admin::editBookDetails/$1', ['as' => 'admin.editBookDetails', 'filter' => 'auth']);
    $routes->add('edit-book-status/(:any)', 'Admin::editBookStatus/$1', ['as' => 'admin.editBookStatus', 'filter' => 'auth']);
    $routes->add('edit-book-extra-image/(:any)', 'Admin::editBookExtraImage/$1', ['as' => 'admin.editBookExtraImage', 'filter' => 'auth']);
    $routes->add('delete-product/(:any)', 'Admin::deleteProduct/$1', ['filter' => 'auth']);
    $routes->add('orders', 'Admin::orders', ['filter' => 'auth']);
    $routes->add('order/(:any)', 'Admin::order/$1', ['filter' => 'auth']);
    $routes->add('users', 'Admin::users', ['filter' => 'auth']);
    $routes->add('gallery', 'Admin::gallery', ['as' => 'admin.gallery', 'filter' => 'auth']);
    $routes->add('upload-gallery-section', 'Admin::gallerySectionUpload', ['as' => 'admin.upload-gallery-section', 'filter' => 'auth']);
    $routes->add('edit-gallery-section/(:any)', 'Admin::gallerySectionEdit/$1', ['as' => 'admin.edit-gallery-section/', 'filter' => 'auth']);
    $routes->add('upload-gallery-image/(:any)', 'Admin::gallerySectionImageUpload/$1', ['as' => 'admin.upload-gallery-image', 'filter' => 'auth']);
    $routes->add('delete-gallery-image/(:any)', 'Admin::galleryImageDelete/$1', ['as' => 'admin.delete-gallery-image', 'filter' => 'auth']);
    $routes->add('upload-gallery-video/(:any)', 'Admin::galleryVideoUpload/$1', ['as' => 'admin.upload-gallery-video', 'filter' => 'auth']);
    $routes->add('delete-gallery-video/(:any)', 'Admin::galleryVideoDelete/$1', ['as' => 'admin.delete-gallery-video', 'filter' => 'auth']);

    $routes->add('upload-product-review/(:any)', 'Admin::productReviewUpload/$1', ['as' => 'admin.upload-product-review', 'filter' => 'auth']);

    $routes->add('delete-review-image/(:any)', 'Admin::productReviewDelete/$1', ['as' => 'admin.delete-review-image', 'filter' => 'auth']);
    $routes->add('logout', 'Admin::logout', ['as' => 'admin.logout', 'filter' => 'auth']);
});
/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
